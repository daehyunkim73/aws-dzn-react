import React from "react";

const api_request_step_one_api_name = (props) => {
  return (
    <React.Fragment>
      <li>
        <input
          type="checkbox"
          className="svc_checkbox_state"
          id={props.check_state}
        />
        <label className="checkbox_design " htmlFor={props.check_state}>
          {props.api_name}
        </label>{" "}
        {props.fare != "" ? <span>{props.fare}</span> : <></>}
      </li>
    </React.Fragment>
  );
};

export default api_request_step_one_api_name;
